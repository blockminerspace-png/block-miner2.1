# Credenciais VPS (local — não commitar)

**Aviso:** este ficheiro está no `.gitignore`. Se expuseres a password, muda-a no servidor.

## SSH / root

| Campo | Valor |
|--------|--------|
| Host | `37.27.38.21` *(default do `deploy-vps-windows.ps1`; ajusta se for outro)* |
| User | `root` |
| Password | `r4mK7RmE4Hcu` |

## Deploy Windows (PuTTY)

Na raiz do repo, o script também aceita `.deploy-pw.txt` com **apenas uma linha** = password (já criado em paralelo).

```powershell
$env:BLOCKMINER_VPS_PW = '***'
.\scripts\deploy-vps-windows.ps1
# ou: .\scripts\deploy-vps-windows.ps1 -PwFile .\.deploy-pw.txt
```
