---
source_path: ".claude/settings.local.json"
domain: workspace
language: "JSON"
extension: ".json"
size_bytes: 79
modified_at: "2026-04-10T14:30:22.000Z"
outbound_local_refs: 0
inbound_local_refs: 0
---

# .claude/settings.local.json

## O que é

Configuração ou estrutura de dados.

## Por que existe

Existe para compor o workspace e apoiar o funcionamento do projeto.

## O que conecta com quem

Sem dependências locais detectadas automaticamente.

## Dependências locais detectadas

- Nenhuma dependência local detectada.

## Referenciado por

- Nenhum backlink local detectado.

## Classificação

- Domínio: `workspace`
- Linguagem/tipo: `JSON`
- Tamanho: `79 bytes`

## Observação técnica

Análise automática baseada em caminho, extensão e referências locais estáticas.

## Navegação

- Voltar ao [[01 - Mapa Detalhado]]
- Ver índice da área em [[30 - Índices/30 - Índice - .claude|.claude]]
