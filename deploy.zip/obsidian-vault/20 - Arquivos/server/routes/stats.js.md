---
source_path: "server/routes/stats.js"
domain: backend
language: "JavaScript"
extension: ".js"
size_bytes: 457
modified_at: "2026-04-08T23:44:11.000Z"
outbound_local_refs: 3
inbound_local_refs: 1
---

# server/routes/stats.js

## O que é

Define endpoints e entrada HTTP.

## Por que existe

Existe para sustentar API, regras de negócio, persistência e automações.

## O que conecta com quem

Conecta-se diretamente aos arquivos listados em dependências locais detectadas.

## Dependências locais detectadas

- Usa [[20 - Arquivos/server/controllers/powerStatsController.js|server/controllers/powerStatsController.js]]
- Usa [[20 - Arquivos/server/middleware/auth.js|server/middleware/auth.js]]
- Usa [[20 - Arquivos/server/middleware/rateLimit.js|server/middleware/rateLimit.js]]

## Referenciado por

- É usado por [[20 - Arquivos/server/server.js|server/server.js]]

## Classificação

- Domínio: `backend`
- Linguagem/tipo: `JavaScript`
- Tamanho: `457 bytes`

## Observação técnica

Análise automática baseada em caminho, extensão e referências locais estáticas.

## Navegação

- Voltar ao [[01 - Mapa Detalhado]]
- Ver índice da área em [[30 - Índices/30 - Índice - server|server]]
