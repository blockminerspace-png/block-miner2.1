---
source_path: "server/src/db/database.sql"
domain: backend
language: "SQL"
extension: ".sql"
size_bytes: 9679
modified_at: "2026-04-02T15:51:05.000Z"
outbound_local_refs: 0
inbound_local_refs: 0
---

# server/src/db/database.sql

## O que é

Arquivo do projeto.

## Por que existe

Existe para sustentar API, regras de negócio, persistência e automações.

## O que conecta com quem

Sem dependências locais detectadas automaticamente.

## Dependências locais detectadas

- Nenhuma dependência local detectada.

## Referenciado por

- Nenhum backlink local detectado.

## Classificação

- Domínio: `backend`
- Linguagem/tipo: `SQL`
- Tamanho: `9679 bytes`

## Observação técnica

Análise automática baseada em caminho, extensão e referências locais estáticas.

## Navegação

- Voltar ao [[01 - Mapa Detalhado]]
- Ver índice da área em [[30 - Índices/30 - Índice - server|server]]
