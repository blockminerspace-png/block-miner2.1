---
source_path: "server/prisma/migrations/20260417130000_transactions_deposit_txhash_unique/migration.sql"
domain: backend
language: "SQL"
extension: ".sql"
size_bytes: 278
modified_at: "2026-04-16T19:42:56.652Z"
outbound_local_refs: 0
inbound_local_refs: 0
---

# server/prisma/migrations/20260417130000_transactions_deposit_txhash_unique/migration.sql

## O que é

Migração de banco de dados Prisma.

## Por que existe

Existe para sustentar API, regras de negócio, persistência e automações.

## O que conecta com quem

Sem dependências locais detectadas automaticamente.

## Dependências locais detectadas

- Nenhuma dependência local detectada.

## Referenciado por

- Nenhum backlink local detectado.

## Classificação

- Domínio: `backend`
- Linguagem/tipo: `SQL`
- Tamanho: `278 bytes`

## Observação técnica

Análise automática baseada em caminho, extensão e referências locais estáticas.

## Navegação

- Voltar ao [[01 - Mapa Detalhado]]
- Ver índice da área em [[30 - Índices/30 - Índice - server|server]]
