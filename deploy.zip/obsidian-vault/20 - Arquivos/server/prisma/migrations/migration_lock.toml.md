---
source_path: "server/prisma/migrations/migration_lock.toml"
domain: backend
language: "TOML"
extension: ".toml"
size_bytes: 130
modified_at: "2026-04-05T21:35:10.000Z"
outbound_local_refs: 0
inbound_local_refs: 0
---

# server/prisma/migrations/migration_lock.toml

## O que é

Migração de banco de dados Prisma.

## Por que existe

Existe para sustentar API, regras de negócio, persistência e automações.

## O que conecta com quem

Sem dependências locais detectadas automaticamente.

## Dependências locais detectadas

- Nenhuma dependência local detectada.

## Referenciado por

- Nenhum backlink local detectado.

## Classificação

- Domínio: `backend`
- Linguagem/tipo: `TOML`
- Tamanho: `130 bytes`

## Observação técnica

Análise automática baseada em caminho, extensão e referências locais estáticas.

## Navegação

- Voltar ao [[01 - Mapa Detalhado]]
- Ver índice da área em [[30 - Índices/30 - Índice - server|server]]
