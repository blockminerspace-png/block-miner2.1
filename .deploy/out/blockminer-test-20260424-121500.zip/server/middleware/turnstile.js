/**
 * Cloudflare Turnstile server-side verification.
 * Optional when no secret is configured for the route (see resolveTurnstileSecret).
 */

import loggerLib from "../utils/logger.js";
import { SecurityErrorCodes, buildSecurityErrorJson } from "../utils/securityErrors.js";

const logger = loggerLib.child("Turnstile");

/** Cloudflare Turnstile dummy secret — only when TURNSTILE_USE_CLOUDFLARE_DUMMY_KEYS is enabled (test/staging). */
const CLOUDFLARE_TURNSTILE_DUMMY_SECRET = "1x0000000000000000000000000000000AA";

function envFlag(name) {
  const raw = String(process.env[name] ?? "").trim().toLowerCase();
  return raw === "1" || raw === "true" || raw === "yes" || raw === "on";
}

function useCloudflareDummyTurnstileKeys() {
  return envFlag("TURNSTILE_USE_CLOUDFLARE_DUMMY_KEYS");
}

/** @typedef {'login' | 'register' | undefined} TurnstilePurpose */

/**
 * Resolves the secret for siteverify. Per-purpose keys override TURNSTILE_SECRET_KEY.
 * Non-auth routes use purpose undefined → TURNSTILE_SECRET_KEY only.
 *
 * @param {TurnstilePurpose} [purpose]
 * @returns {string}
 */
export function resolveTurnstileSecret(purpose) {
  if (useCloudflareDummyTurnstileKeys()) {
    return CLOUDFLARE_TURNSTILE_DUMMY_SECRET;
  }
  const fallback = String(process.env.TURNSTILE_SECRET_KEY || "").trim();
  if (purpose === "login") {
    return String(process.env.TURNSTILE_SECRET_KEY_LOGIN || "").trim() || fallback;
  }
  if (purpose === "register") {
    return String(process.env.TURNSTILE_SECRET_KEY_REGISTER || "").trim() || fallback;
  }
  return fallback;
}

export function isTurnstileEnforced() {
  return resolveTurnstileSecret(undefined).length > 0;
}

function isNodeProduction() {
  return String(process.env.NODE_ENV || "").toLowerCase() === "production";
}

/**
 * If non-empty, the process must not continue (Turnstile dummy keys in production without escape hatch).
 * @returns {string}
 */
export function getTurnstileBootFatalError() {
  if (!isNodeProduction()) return "";
  if (!useCloudflareDummyTurnstileKeys()) return "";
  if (envFlag("ALLOW_TURNSTILE_DUMMY_IN_PRODUCTION")) return "";
  return (
    "Refusing to start: NODE_ENV=production with TURNSTILE_USE_CLOUDFLARE_DUMMY_KEYS enabled uses Cloudflare test " +
      "secrets only (pink test banner, not real security). Unset TURNSTILE_USE_CLOUDFLARE_DUMMY_KEYS and " +
      "VITE_TURNSTILE_DUMMY_FALLBACK, set TURNSTILE_SECRET_KEY_LOGIN + VITE_TURNSTILE_SITE_KEY_LOGIN, rebuild the app image. " +
      "Emergency only: ALLOW_TURNSTILE_DUMMY_IN_PRODUCTION=1."
  );
}

/**
 * Production: exit if dummy Turnstile is on (unless ALLOW_TURNSTILE_DUMMY_IN_PRODUCTION).
 * Non-production: warn when dummy is on.
 */
export function runTurnstileStartupChecks() {
  const fatal = getTurnstileBootFatalError();
  if (fatal) {
    logger.error(fatal);
    process.exit(1);
  }
  if (!useCloudflareDummyTurnstileKeys()) return;
  if (isNodeProduction() && envFlag("ALLOW_TURNSTILE_DUMMY_IN_PRODUCTION")) {
    logger.warn(
      "ALLOW_TURNSTILE_DUMMY_IN_PRODUCTION is set: Turnstile still uses Cloudflare dummy keys (test-only banner)."
    );
    return;
  }
  logger.warn(
    "TURNSTILE_USE_CLOUDFLARE_DUMMY_KEYS is enabled: Cloudflare shows the test-only banner in the widget. " +
      "Unset it and set real TURNSTILE_SECRET_KEY_LOGIN + VITE_TURNSTILE_SITE_KEY_LOGIN for production-like hosts, then rebuild the app image."
  );
}

/**
 * @param {string | undefined | null} token
 * @param {string | undefined} remoteIp
 * @param {{ secret?: string }} [options] If `secret` is omitted, uses TURNSTILE_SECRET_KEY (legacy callers).
 */
export async function verifyTurnstileToken(token, remoteIp, options = {}) {
  const secret = String(options.secret ?? process.env.TURNSTILE_SECRET_KEY ?? "").trim();
  if (!secret) {
    return { ok: true, skipped: true };
  }
  const t = String(token || "").trim();
  if (!t) {
    return { ok: false, code: SecurityErrorCodes.CAPTCHA_REQUIRED };
  }
  const body = new URLSearchParams();
  body.set("secret", secret);
  body.set("response", t);
  if (remoteIp) body.set("remoteip", remoteIp);

  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body,
    });
    const json = await res.json().catch(() => ({}));
    if (json?.success === true) {
      return { ok: true, skipped: false };
    }
    logger.warn("Turnstile verification failed", { errorCodes: json?.["error-codes"] });
    return { ok: false, code: SecurityErrorCodes.CAPTCHA_FAILED };
  } catch (e) {
    logger.error("Turnstile request error", { message: /** @type {Error} */ (e).message });
    if (envFlag("TURNSTILE_FAIL_OPEN")) {
      return { ok: true, skipped: true };
    }
    return { ok: false, code: SecurityErrorCodes.CAPTCHA_FAILED };
  }
}

/**
 * @param {unknown} arg
 * @returns {TurnstilePurpose}
 */
function normalizeTurnstilePurpose(arg) {
  if (arg === "login" || arg === "register") return arg;
  if (arg && typeof arg === "object") {
    const p = /** @type {{ purpose?: unknown }} */ (arg).purpose;
    if (p === "login" || p === "register") return p;
  }
  return undefined;
}

/**
 * Reads token from body.cfTurnstileToken or X-Turnstile-Token header.
 * @param {{ purpose?: 'login' | 'register' } | 'login' | 'register' | undefined} [arg]
 * @returns {import("express").RequestHandler}
 */
export function requireTurnstileWhenConfigured(arg) {
  const purpose = normalizeTurnstilePurpose(arg);
  return async (req, res, next) => {
    const secret = resolveTurnstileSecret(purpose);
    if (!secret) {
      next();
      return;
    }
    const token = req.body?.cfTurnstileToken ?? req.headers["x-turnstile-token"];
    const ip = String(req.ip || req.socket?.remoteAddress || "");
    const result = await verifyTurnstileToken(token, ip, { secret });
    if (!result.ok) {
      const code = result.code || SecurityErrorCodes.CAPTCHA_FAILED;
      return res.status(400).json(buildSecurityErrorJson(code));
    }
    next();
  };
}
